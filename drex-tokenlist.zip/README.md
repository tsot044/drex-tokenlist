# DREX Coin Token List

Lista oficial do token **DREX Coin (DRX)** na Base Mainnet.

- Website: https://drexcoin.fasst.space/
- Token Address: `0x0C1c8B1cD7570f6796b303aA489810aD0E81836F`
- Lista compatível com Uniswap Token List Specification
- Logo disponível via HTTPS

## Visibilidade

Aparecerá corretamente em carteiras como MetaMask, Trust Wallet e Uniswap após:

- Verificação do contrato
- Adição de liquidez
- Inclusão na lista oficial do Uniswap (opcional)